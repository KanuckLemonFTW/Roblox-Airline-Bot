const { SlashCommandBuilder } = require('discord.js');
const db     = require('../../utils/db');
const { checkPerm, getMemberLevel, ROLE_HIERARCHY } = require('../../utils/permissions');
const { successEmbed, errorEmbed, airlineEmbed } = require('../../utils/embeds');
const config = require('../../config');

// ─── /hire ────────────────────────────────────────────────────────────────────
const hire = {
  data: new SlashCommandBuilder()
    .setName('hire')
    .setDescription('[HR] Hire a new staff member and assign their role')
    .addUserOption(o => o.setName('user').setDescription('User to hire').setRequired(true))
    .addStringOption(o => o.setName('position').setDescription('Position to assign').setRequired(true)
      .addChoices(
        { name: '🧑‍✈️ Pilot',         value: 'pilot'      },
        { name: '✈️ Cabin Crew',      value: 'crew'       },
        { name: '📋 Dispatcher',      value: 'dispatcher' },
        { name: '🔍 Supervisor',      value: 'supervisor' },
        { name: '👔 HR Manager',      value: 'hr'         },
      )),

  async execute(interaction) {
    if (!await checkPerm(interaction, 'MANAGE_STAFF')) return;

    const target   = interaction.options.getMember('user');
    const position = interaction.options.getString('position');
    const roleId   = config.roles[position];

    if (!roleId) {
      return interaction.reply({ embeds: [errorEmbed('Config Error', `No role ID configured for **${position}**. Set it in \`.env\`.`)], ephemeral: true });
    }

    // Prevent HR from hiring Owner
    if (position === 'owner' && !interaction.member.permissions.has('Administrator')) {
      return interaction.reply({ embeds: [errorEmbed('Access Denied', 'Only server administrators can assign the Owner role.')], ephemeral: true });
    }

    try {
      await target.roles.add(roleId);

      // Also assign passenger role if configured
      if (config.roles.passenger) {
        await target.roles.add(config.roles.passenger).catch(() => {});
      }

      const member = {
        userId:    target.id,
        userTag:   target.user.tag,
        position,
        hiredBy:   interaction.user.id,
        hiredAt:   new Date().toISOString(),
        flightsWorked: 0,
      };
      db.saveStaffMember(member);

      await interaction.reply({ embeds: [
        successEmbed('Staff Hired', `<@${target.id}> has been hired as a **${position.charAt(0).toUpperCase()+position.slice(1)}**!\nWelcome to ${config.airline.name}! 🎉`),
      ]});

      // Staff log
      if (config.channels.staffLog) {
        const logCh = interaction.guild.channels.cache.get(config.channels.staffLog);
        if (logCh) logCh.send({ embeds: [
          successEmbed('New Hire', `**${interaction.user.tag}** hired <@${target.id}> as **${position}**.`),
        ]});
      }

      // DM the new hire
      target.send({
        embeds: [airlineEmbed(
          `Welcome to ${config.airline.name}! ✈️`,
          `Congratulations! You've been hired as **${position.charAt(0).toUpperCase()+position.slice(1)}**.\n\nWelcome to the team! Check in with your supervisor for your first assignment.`
        )]
      }).catch(() => {}); // Don't fail if DMs are closed

    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed('Failed to Hire', `Could not assign role: ${err.message}`)], ephemeral: true });
    }
  },
};

// ─── /fire ────────────────────────────────────────────────────────────────────
const fire = {
  data: new SlashCommandBuilder()
    .setName('fire')
    .setDescription('[HR] Remove a staff member')
    .addUserOption(o => o.setName('user').setDescription('Staff member to remove').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for removal').setRequired(false)),

  async execute(interaction) {
    if (!await checkPerm(interaction, 'MANAGE_STAFF')) return;

    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason given';
    const member = db.getStaffMember(target.id);

    // Remove all airline roles
    const rolesToRemove = Object.values(config.roles).filter(Boolean);
    await target.roles.remove(rolesToRemove).catch(() => {});

    db.removeStaffMember(target.id);

    await interaction.reply({ embeds: [
      successEmbed('Staff Removed', `<@${target.id}> has been removed from the team.\nReason: ${reason}`),
    ]});

    if (config.channels.staffLog) {
      const logCh = interaction.guild.channels.cache.get(config.channels.staffLog);
      if (logCh) logCh.send({ embeds: [
        errorEmbed('Staff Removed', `**${interaction.user.tag}** removed <@${target.id}> from staff.\nReason: ${reason}`),
      ]});
    }

    target.send({ embeds: [
      errorEmbed(`Removed from ${config.airline.name}`, `You have been removed from the team.\nReason: ${reason}\n\nContact HR if you believe this is an error.`)
    ]}).catch(() => {});
  },
};

// ─── /promote ─────────────────────────────────────────────────────────────────
const promote = {
  data: new SlashCommandBuilder()
    .setName('promote')
    .setDescription('[HR] Promote a staff member to a new position')
    .addUserOption(o => o.setName('user').setDescription('Staff member to promote').setRequired(true))
    .addStringOption(o => o.setName('position').setDescription('New position').setRequired(true)
      .addChoices(
        { name: '🧑‍✈️ Pilot',     value: 'pilot'      },
        { name: '✈️ Cabin Crew', value: 'crew'       },
        { name: '📋 Dispatcher', value: 'dispatcher' },
        { name: '🔍 Supervisor', value: 'supervisor' },
        { name: '👔 HR Manager', value: 'hr'         },
      )),

  async execute(interaction) {
    if (!await checkPerm(interaction, 'MANAGE_STAFF')) return;

    const target   = interaction.options.getMember('user');
    const position = interaction.options.getString('position');
    const newRoleId = config.roles[position];

    if (!newRoleId) {
      return interaction.reply({ embeds: [errorEmbed('Config Error', `Role ID not configured for **${position}**.`)], ephemeral: true });
    }

    // Remove existing staff roles, then add new one
    const staffRoleIds = ['pilot','crew','dispatcher','supervisor','hr']
      .map(r => config.roles[r]).filter(Boolean);

    await target.roles.remove(staffRoleIds).catch(() => {});
    await target.roles.add(newRoleId);

    // Update DB
    let staffMember = db.getStaffMember(target.id) || {
      userId: target.id, userTag: target.user.tag,
      hiredBy: interaction.user.id, hiredAt: new Date().toISOString(), flightsWorked: 0,
    };
    staffMember.position = position;
    staffMember.lastPromotedBy = interaction.user.id;
    staffMember.lastPromotedAt = new Date().toISOString();
    db.saveStaffMember(staffMember);

    await interaction.reply({ embeds: [
      successEmbed('Staff Promoted', `<@${target.id}> has been promoted to **${position.charAt(0).toUpperCase()+position.slice(1)}**! 🎉`)
    ]});

    target.send({ embeds: [
      successEmbed(`Promoted at ${config.airline.name}! 🎉`, `Congratulations! You've been promoted to **${position.charAt(0).toUpperCase()+position.slice(1)}**.`)
    ]}).catch(() => {});
  },
};

// ─── /stafflist ───────────────────────────────────────────────────────────────
const staffList = {
  data: new SlashCommandBuilder()
    .setName('stafflist')
    .setDescription('View all current staff members'),

  async execute(interaction) {
    if (!await checkPerm(interaction, 'VIEW_STAFF_LIST')) return;

    const staff = db.getStaff();

    if (staff.length === 0) {
      return interaction.reply({ embeds: [airlineEmbed('👥 Staff List', 'No staff members found.')], ephemeral: true });
    }

    const grouped = {};
    for (const s of staff) {
      if (!grouped[s.position]) grouped[s.position] = [];
      grouped[s.position].push(s);
    }

    const positionOrder = ['hr', 'supervisor', 'dispatcher', 'pilot', 'crew'];
    const positionLabel = { hr: '👔 HR Managers', supervisor: '🔍 Supervisors', dispatcher: '📋 Dispatchers', pilot: '🧑‍✈️ Pilots', crew: '✈️ Cabin Crew' };

    const embed = airlineEmbed('👥 Staff List', `**${config.airline.name}** — ${staff.length} staff member(s)`);

    for (const pos of positionOrder) {
      if (grouped[pos]?.length > 0) {
        embed.addFields({
          name:  positionLabel[pos] || pos,
          value: grouped[pos].map(s => `• <@${s.userId}>`).join('\n'),
        });
      }
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

// ─── /staffinfo ───────────────────────────────────────────────────────────────
const staffInfo = {
  data: new SlashCommandBuilder()
    .setName('staffinfo')
    .setDescription('View info about a staff member')
    .addUserOption(o => o.setName('user').setDescription('Staff member').setRequired(true)),

  async execute(interaction) {
    if (!await checkPerm(interaction, 'VIEW_STAFF_LIST')) return;

    const target = interaction.options.getMember('user');
    const member = db.getStaffMember(target.id);

    if (!member) {
      return interaction.reply({ embeds: [errorEmbed('Not Found', `<@${target.id}> is not in the staff database.`)], ephemeral: true });
    }

    const embed = airlineEmbed(`👤 Staff Profile — ${target.user.tag}`)
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'Position', value: member.position.charAt(0).toUpperCase()+member.position.slice(1), inline: true },
        { name: 'Hired By', value: `<@${member.hiredBy}>`, inline: true },
        { name: 'Hired At', value: new Date(member.hiredAt).toLocaleDateString(), inline: true },
        { name: 'Flights Worked', value: String(member.flightsWorked || 0), inline: true },
      );

    if (member.lastPromotedAt) {
      embed.addFields({ name: 'Last Promoted', value: new Date(member.lastPromotedAt).toLocaleDateString(), inline: true });
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

module.exports = { hire, fire, promote, staffList, staffInfo };
