const {
  SlashCommandBuilder, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, StringSelectMenuBuilder,
} = require('discord.js');
const { v4: uuidv4 } = require('uuid');
const db     = require('../../utils/db');
const { checkPerm } = require('../../utils/permissions');
const { bookingEmbed, errorEmbed, successEmbed, airlineEmbed, CLASS_EMOJI } = require('../../utils/embeds');
const config = require('../../config');

// ─── /book ────────────────────────────────────────────────────────────────────
const bookFlight = {
  data: new SlashCommandBuilder()
    .setName('book')
    .setDescription('Book a seat on a flight')
    .addStringOption(o => o.setName('flight_number').setDescription('Flight number (e.g. SKL123)').setRequired(true))
    .addStringOption(o => o.setName('class').setDescription('Seat class').setRequired(true)
      .addChoices(
        { name: '💺 Economy',  value: 'economy'  },
        { name: '🛋️ Business', value: 'business' },
        { name: '👑 First',    value: 'first'    },
      )),

  async execute(interaction) {
    if (!await checkPerm(interaction, 'BOOK_FLIGHT')) return;

    const num        = interaction.options.getString('flight_number');
    const seatClass  = interaction.options.getString('class');
    const flight     = db.getFlightByNumber(num);

    if (!flight) {
      return interaction.reply({ embeds: [errorEmbed('Flight Not Found', `No flight found with number **${num.toUpperCase()}**.`)], ephemeral: true });
    }

    if (['cancelled', 'departed', 'arrived'].includes(flight.status)) {
      return interaction.reply({ embeds: [errorEmbed('Cannot Book', `Flight **${num}** is **${flight.status}** and cannot be booked.`)], ephemeral: true });
    }

    // Check seat availability
    const available = (flight.seats?.[seatClass] || 0) - (flight.booked?.[seatClass] || 0);
    if (available <= 0) {
      return interaction.reply({ embeds: [errorEmbed('No Seats Available', `**${seatClass.charAt(0).toUpperCase()+seatClass.slice(1)}** class is fully booked on this flight.`)], ephemeral: true });
    }

    // Check for duplicate booking
    const existing = db.getBookingsByFlight(flight.id).find(b => b.userId === interaction.user.id);
    if (existing) {
      return interaction.reply({ embeds: [errorEmbed('Already Booked', `You already have a booking on this flight!\nBooking ID: \`${existing.id}\``)], ephemeral: true });
    }

    // Confirm booking
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`confirm_book_${flight.id}_${seatClass}`).setLabel('Confirm Booking').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('cancel_booking').setLabel('Cancel').setStyle(ButtonStyle.Secondary),
    );

    const classEmoji = CLASS_EMOJI[seatClass];
    await interaction.reply({
      embeds: [airlineEmbed(
        `Confirm Booking — ${flight.flightNumber}`,
        `**${flight.departure} → ${flight.arrival}**\nDeparture: ${flight.departureTime}\nGate: ${flight.gate || 'TBD'}\nClass: ${classEmoji} ${seatClass.charAt(0).toUpperCase()+seatClass.slice(1)}\n\nConfirm your booking?`
      )],
      components: [row],
      ephemeral: true,
    });

    const collector = interaction.channel.createMessageComponentCollector({ time: 60000 });
    collector.on('collect', async btn => {
      if (btn.user.id !== interaction.user.id) return;
      collector.stop();

      if (btn.customId === `confirm_book_${flight.id}_${seatClass}`) {
        // Create booking
        const booking = {
          id:       uuidv4().slice(0, 8).toUpperCase(),
          flightId: flight.id,
          userId:   interaction.user.id,
          userTag:  interaction.user.tag,
          class:    seatClass,
          status:   'confirmed',
          seat:     null,
          bookedAt: new Date().toISOString(),
        };

        // Increment booked count
        if (!flight.booked) flight.booked = { economy: 0, business: 0, first: 0 };
        flight.booked[seatClass] = (flight.booked[seatClass] || 0) + 1;

        db.saveBooking(booking);
        db.saveFlight(flight);

        await btn.update({ embeds: [bookingEmbed(booking, flight)], components: [] });

        // Log booking
        if (config.channels.bookingLog) {
          const logCh = interaction.guild.channels.cache.get(config.channels.bookingLog);
          if (logCh) {
            logCh.send({ embeds: [
              bookingEmbed(booking, flight)
                .setTitle(`🎫 New Booking — ${booking.id}`)
                .addFields({ name: 'Passenger', value: `<@${interaction.user.id}> (${interaction.user.tag})` }),
            ]});
          }
        }
      } else {
        await btn.update({ embeds: [errorEmbed('Booking Cancelled', 'Your booking was not confirmed.')], components: [] });
      }
    });

    collector.on('end', (_, reason) => {
      if (reason === 'time') {
        interaction.editReply({ embeds: [errorEmbed('Booking Timed Out', 'Your booking session expired.')], components: [] }).catch(() => {});
      }
    });
  },
};

// ─── /mybookings ──────────────────────────────────────────────────────────────
const myBookings = {
  data: new SlashCommandBuilder()
    .setName('mybookings')
    .setDescription('View your current flight bookings'),

  async execute(interaction) {
    const bookings = db.getBookingsByUser(interaction.user.id)
      .filter(b => b.status !== 'cancelled');

    if (bookings.length === 0) {
      return interaction.reply({
        embeds: [airlineEmbed('🎫 Your Bookings', "You don't have any active bookings.\nUse `/book` to book a flight!")],
        ephemeral: true,
      });
    }

    const embed = airlineEmbed('🎫 Your Bookings', `You have **${bookings.length}** active booking(s):`);

    for (const b of bookings) {
      const flight = db.getFlight(b.flightId);
      if (!flight) continue;
      embed.addFields({
        name: `Booking \`${b.id}\` — Flight ${flight.flightNumber}`,
        value: `${CLASS_EMOJI[b.class]} ${b.class} | ${flight.departure} → ${flight.arrival} | Departs: ${flight.departureTime} | Status: ${flight.status}`,
      });
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

// ─── /cancelbooking ───────────────────────────────────────────────────────────
const cancelBooking = {
  data: new SlashCommandBuilder()
    .setName('cancelbooking')
    .setDescription('Cancel one of your bookings')
    .addStringOption(o => o.setName('booking_id').setDescription('Your booking ID').setRequired(true)),

  async execute(interaction) {
    const bookingId = interaction.options.getString('booking_id').toUpperCase();
    const booking   = db.getBooking(bookingId);

    if (!booking) {
      return interaction.reply({ embeds: [errorEmbed('Not Found', `Booking \`${bookingId}\` not found.`)], ephemeral: true });
    }

    if (booking.userId !== interaction.user.id && !await checkPerm(interaction, 'VIEW_BOOKINGS')) {
      return interaction.reply({ embeds: [errorEmbed('Access Denied', "You can only cancel your own bookings.")], ephemeral: true });
    }

    if (booking.status === 'cancelled') {
      return interaction.reply({ embeds: [errorEmbed('Already Cancelled', 'This booking is already cancelled.')], ephemeral: true });
    }

    const flight = db.getFlight(booking.flightId);

    booking.status = 'cancelled';
    db.saveBooking(booking);

    // Refund the seat
    if (flight && flight.booked) {
      flight.booked[booking.class] = Math.max(0, (flight.booked[booking.class] || 1) - 1);
      db.saveFlight(flight);
    }

    await interaction.reply({
      embeds: [successEmbed('Booking Cancelled', `Booking \`${bookingId}\` has been cancelled.${flight ? `\nFlight: **${flight.flightNumber}** (${flight.departure} → ${flight.arrival})` : ''}`)],
      ephemeral: true,
    });
  },
};

// ─── /viewbookings (staff) ────────────────────────────────────────────────────
const viewBookings = {
  data: new SlashCommandBuilder()
    .setName('viewbookings')
    .setDescription('[Staff] View all bookings for a flight')
    .addStringOption(o => o.setName('flight_number').setDescription('Flight number').setRequired(true)),

  async execute(interaction) {
    if (!await checkPerm(interaction, 'VIEW_BOOKINGS')) return;

    const num    = interaction.options.getString('flight_number');
    const flight = db.getFlightByNumber(num);

    if (!flight) {
      return interaction.reply({ embeds: [errorEmbed('Not Found', `Flight **${num}** not found.`)], ephemeral: true });
    }

    const bookings = db.getBookingsByFlight(flight.id).filter(b => b.status !== 'cancelled');

    const embed = airlineEmbed(
      `📋 Bookings — ${flight.flightNumber}`,
      `**${flight.departure} → ${flight.arrival}** | ${flight.departureTime}\nTotal confirmed bookings: **${bookings.length}**`
    );

    const classes = ['economy', 'business', 'first'];
    for (const c of classes) {
      const classBookings = bookings.filter(b => b.class === c);
      if (classBookings.length > 0) {
        embed.addFields({
          name: `${CLASS_EMOJI[c]} ${c.charAt(0).toUpperCase()+c.slice(1)} (${classBookings.length}/${flight.seats?.[c]||0})`,
          value: classBookings.map(b => `• <@${b.userId}> — \`${b.id}\``).join('\n') || 'None',
        });
      }
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

module.exports = { bookFlight, myBookings, cancelBooking, viewBookings };
