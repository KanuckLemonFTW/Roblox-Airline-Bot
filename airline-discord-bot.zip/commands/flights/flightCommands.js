const {
  SlashCommandBuilder, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const { v4: uuidv4 } = require('uuid');
const db    = require('../../utils/db');
const { checkPerm }   = require('../../utils/permissions');
const { flightEmbed, successEmbed, errorEmbed, airlineEmbed, STATUS_EMOJI } = require('../../utils/embeds');
const config = require('../../config');

// ─── /flight create ───────────────────────────────────────────────────────────
const createFlight = {
  data: new SlashCommandBuilder()
    .setName('createflight')
    .setDescription('Create a new flight')
    .addStringOption(o => o.setName('departure').setDescription('Departure airport/city').setRequired(true))
    .addStringOption(o => o.setName('arrival').setDescription('Arrival airport/city').setRequired(true))
    .addStringOption(o => o.setName('departure_time').setDescription('Departure time (e.g. 3:00 PM EST)').setRequired(true))
    .addStringOption(o => o.setName('arrival_time').setDescription('Arrival time (e.g. 5:30 PM EST)').setRequired(true))
    .addStringOption(o => o.setName('aircraft').setDescription('Aircraft type (e.g. Boeing 737)').setRequired(true))
    .addIntegerOption(o => o.setName('economy_seats').setDescription('Number of economy seats').setRequired(true))
    .addIntegerOption(o => o.setName('business_seats').setDescription('Number of business class seats').setRequired(false))
    .addIntegerOption(o => o.setName('first_seats').setDescription('Number of first class seats').setRequired(false))
    .addStringOption(o => o.setName('gate').setDescription('Gate number/name').setRequired(false))
    .addUserOption(o => o.setName('pilot').setDescription('Assigned pilot').setRequired(false))
    .addStringOption(o => o.setName('notes').setDescription('Additional notes').setRequired(false)),

  async execute(interaction) {
    if (!await checkPerm(interaction, 'CREATE_FLIGHT')) return;

    const departure     = interaction.options.getString('departure');
    const arrival       = interaction.options.getString('arrival');
    const departureTime = interaction.options.getString('departure_time');
    const arrivalTime   = interaction.options.getString('arrival_time');
    const aircraft      = interaction.options.getString('aircraft');
    const econSeats     = interaction.options.getInteger('economy_seats');
    const bizSeats      = interaction.options.getInteger('business_seats') || 0;
    const firstSeats    = interaction.options.getInteger('first_seats') || 0;
    const gate          = interaction.options.getString('gate');
    const pilotUser     = interaction.options.getUser('pilot');
    const notes         = interaction.options.getString('notes');

    // Generate flight number: AIRLINE_CODE + random 3-digit
    const flightNumber = `${config.airline.code}${Math.floor(100 + Math.random() * 900)}`;

    const flight = {
      id:            uuidv4().slice(0, 8).toUpperCase(),
      flightNumber,
      departure:     departure.toUpperCase(),
      arrival:       arrival.toUpperCase(),
      departureTime,
      arrivalTime,
      aircraft,
      gate:          gate || null,
      pilotId:       pilotUser?.id || null,
      pilotTag:      pilotUser?.tag || null,
      notes:         notes || null,
      status:        'scheduled',
      seats:   { economy: econSeats, business: bizSeats, first: firstSeats },
      booked:  { economy: 0, business: 0, first: 0 },
      createdBy: interaction.user.id,
      createdAt: new Date().toISOString(),
    };

    db.saveFlight(flight);

    const embed = flightEmbed(flight)
      .setTitle(`✅ Flight Created — ${flight.flightNumber}`)
      .setColor(0x38A169);

    await interaction.reply({ embeds: [embed] });

    // Announce in flights channel if configured
    if (config.channels.flights) {
      const channel = interaction.guild.channels.cache.get(config.channels.flights);
      if (channel) {
        const announceEmbed = flightEmbed(flight);
        await channel.send({ content: '🛫 **New Flight Available!**', embeds: [announceEmbed] });
      }
    }

    // Log to staff log
    if (config.channels.staffLog) {
      const logCh = interaction.guild.channels.cache.get(config.channels.staffLog);
      if (logCh) {
        logCh.send({ embeds: [
          successEmbed('Flight Created', `**${interaction.user.tag}** created flight **${flight.flightNumber}** (${departure.toUpperCase()} → ${arrival.toUpperCase()})`)
        ]});
      }
    }
  },
};

// ─── /listflights ─────────────────────────────────────────────────────────────
const listFlights = {
  data: new SlashCommandBuilder()
    .setName('listflights')
    .setDescription('View all active flights'),

  async execute(interaction) {
    const flights = db.getActiveFlights();

    if (flights.length === 0) {
      return interaction.reply({
        embeds: [airlineEmbed('✈️ No Flights Scheduled', 'There are currently no scheduled flights. Check back later!')],
      });
    }

    const embed = airlineEmbed('✈️ Active Flights', `Found **${flights.length}** active flight(s):`);

    for (const f of flights.slice(0, 10)) {
      const totalSeats  = (f.seats?.economy||0)+(f.seats?.business||0)+(f.seats?.first||0);
      const bookedSeats = (f.booked?.economy||0)+(f.booked?.business||0)+(f.booked?.first||0);
      const avail = totalSeats - bookedSeats;

      embed.addFields({
        name: `${STATUS_EMOJI[f.status]||'✈️'} ${f.flightNumber} — ${f.departure} → ${f.arrival}`,
        value: `**Departs:** ${f.departureTime} | **Gate:** ${f.gate||'TBD'} | **Seats:** ${avail}/${totalSeats} | **Status:** ${f.status}`,
      });
    }

    if (flights.length > 10) embed.setFooter({ text: `Showing 10 of ${flights.length} flights` });

    await interaction.reply({ embeds: [embed] });
  },
};

// ─── /flightinfo ──────────────────────────────────────────────────────────────
const flightInfo = {
  data: new SlashCommandBuilder()
    .setName('flightinfo')
    .setDescription('View detailed info about a specific flight')
    .addStringOption(o => o.setName('flight_number').setDescription('Flight number (e.g. SKL123)').setRequired(true)),

  async execute(interaction) {
    const num    = interaction.options.getString('flight_number');
    const flight = db.getFlightByNumber(num);

    if (!flight) {
      return interaction.reply({ embeds: [errorEmbed('Flight Not Found', `No flight found with number **${num.toUpperCase()}**.`)], ephemeral: true });
    }

    await interaction.reply({ embeds: [flightEmbed(flight)] });
  },
};

// ─── /updateflight ────────────────────────────────────────────────────────────
const updateFlight = {
  data: new SlashCommandBuilder()
    .setName('updateflight')
    .setDescription('Update a flight\'s status or details')
    .addStringOption(o => o.setName('flight_number').setDescription('Flight number').setRequired(true))
    .addStringOption(o => o.setName('status').setDescription('New status').setRequired(false)
      .addChoices(
        { name: '🕐 Scheduled', value: 'scheduled' },
        { name: '🚪 Boarding',  value: 'boarding'  },
        { name: '✈️ Departed',  value: 'departed'  },
        { name: '🛬 Arrived',   value: 'arrived'   },
        { name: '⏰ Delayed',   value: 'delayed'   },
      ))
    .addStringOption(o => o.setName('gate').setDescription('Update gate').setRequired(false))
    .addStringOption(o => o.setName('departure_time').setDescription('Update departure time').setRequired(false))
    .addStringOption(o => o.setName('notes').setDescription('Update notes').setRequired(false))
    .addUserOption(o => o.setName('pilot').setDescription('Assign pilot').setRequired(false)),

  async execute(interaction) {
    if (!await checkPerm(interaction, 'EDIT_FLIGHT')) return;

    const num    = interaction.options.getString('flight_number');
    const flight = db.getFlightByNumber(num);

    if (!flight) {
      return interaction.reply({ embeds: [errorEmbed('Not Found', `Flight **${num}** not found.`)], ephemeral: true });
    }

    const status        = interaction.options.getString('status');
    const gate          = interaction.options.getString('gate');
    const departureTime = interaction.options.getString('departure_time');
    const notes         = interaction.options.getString('notes');
    const pilotUser     = interaction.options.getUser('pilot');

    if (status)        flight.status = status;
    if (gate)          flight.gate = gate;
    if (departureTime) flight.departureTime = departureTime;
    if (notes)         flight.notes = notes;
    if (pilotUser)     { flight.pilotId = pilotUser.id; flight.pilotTag = pilotUser.tag; }

    db.saveFlight(flight);

    await interaction.reply({ embeds: [
      flightEmbed(flight).setTitle(`✅ Flight Updated — ${flight.flightNumber}`)
        .setColor(0x38A169),
    ]});

    // Notify flights channel on status changes
    if (status && config.channels.flights) {
      const ch = interaction.guild.channels.cache.get(config.channels.flights);
      if (ch) {
        ch.send({ content: `${STATUS_EMOJI[status]||'✈️'} **Flight Status Update:** ${flight.flightNumber}`, embeds: [flightEmbed(flight)] });
      }
    }
  },
};

// ─── /cancelflight ────────────────────────────────────────────────────────────
const cancelFlight = {
  data: new SlashCommandBuilder()
    .setName('cancelflight')
    .setDescription('Cancel a flight and notify all passengers')
    .addStringOption(o => o.setName('flight_number').setDescription('Flight number').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Cancellation reason').setRequired(false)),

  async execute(interaction) {
    if (!await checkPerm(interaction, 'CANCEL_FLIGHT')) return;

    const num    = interaction.options.getString('flight_number');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const flight = db.getFlightByNumber(num);

    if (!flight) {
      return interaction.reply({ embeds: [errorEmbed('Not Found', `Flight **${num}** not found.`)], ephemeral: true });
    }

    if (flight.status === 'cancelled') {
      return interaction.reply({ embeds: [errorEmbed('Already Cancelled', 'This flight is already cancelled.')], ephemeral: true });
    }

    // Confirm with a button
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`confirm_cancel_${flight.id}`).setLabel('Yes, Cancel Flight').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('cancel_action').setLabel('Abort').setStyle(ButtonStyle.Secondary),
    );

    await interaction.reply({
      embeds: [errorEmbed(`Cancel Flight ${flight.flightNumber}?`, `**${flight.departure} → ${flight.arrival}** at ${flight.departureTime}\nReason: ${reason}\n\nThis will notify all ${(flight.booked?.economy||0)+(flight.booked?.business||0)+(flight.booked?.first||0)} passenger(s).`)],
      components: [row],
      ephemeral: true,
    });

    const collector = interaction.channel.createMessageComponentCollector({ time: 30000 });
    collector.on('collect', async btn => {
      if (btn.user.id !== interaction.user.id) return;

      if (btn.customId === `confirm_cancel_${flight.id}`) {
        flight.status = 'cancelled';
        flight.cancelReason = reason;
        db.saveFlight(flight);

        await btn.update({ embeds: [successEmbed(`Flight ${flight.flightNumber} Cancelled`, `Reason: ${reason}`)], components: [] });

        // Notify flights channel
        if (config.channels.flights) {
          const ch = interaction.guild.channels.cache.get(config.channels.flights);
          if (ch) {
            ch.send({ content: '❌ **Flight Cancelled**', embeds: [
              flightEmbed(flight).addFields({ name: '❌ Cancellation Reason', value: reason }),
            ]});
          }
        }
      } else {
        await btn.update({ embeds: [airlineEmbed('Aborted', 'Cancellation was not executed.')], components: [] });
      }
      collector.stop();
    });
  },
};

module.exports = { createFlight, listFlights, flightInfo, updateFlight, cancelFlight };
