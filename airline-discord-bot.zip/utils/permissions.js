const config = require('../config');

const ROLE_HIERARCHY = ['passenger', 'crew', 'pilot', 'dispatcher', 'supervisor', 'hr', 'owner'];

/**
 * Get the highest airline role level of a guild member.
 * Returns the role key string, or null if they have no airline role.
 */
function getMemberLevel(member) {
  const roles = config.roles;

  // Check from highest to lowest
  for (const level of [...ROLE_HIERARCHY].reverse()) {
    const roleId = roles[level];
    if (roleId && member.roles.cache.has(roleId)) {
      return level;
    }
  }

  return null; // No airline role
}

/**
 * Returns true if the member has at least the given permission.
 * @param {GuildMember} member
 * @param {string} permission - key from config.permissions
 */
function hasPermission(member, permission) {
  // Server admins always pass
  if (member.permissions.has('Administrator')) return true;

  const allowedLevels = config.permissions[permission];
  if (!allowedLevels) return false;

  const memberLevel = getMemberLevel(member);
  if (!memberLevel) return false;

  return allowedLevels.includes(memberLevel);
}

/**
 * Returns true if the member's level is at least `minLevel`.
 */
function hasMinLevel(member, minLevel) {
  if (member.permissions.has('Administrator')) return true;
  const memberLevel = getMemberLevel(member);
  if (!memberLevel) return false;
  return ROLE_HIERARCHY.indexOf(memberLevel) >= ROLE_HIERARCHY.indexOf(minLevel);
}

/**
 * Replies with a permission-denied embed and returns false.
 * Use as: if (!checkPerm(interaction, 'CREATE_FLIGHT')) return;
 */
async function checkPerm(interaction, permission) {
  if (hasPermission(interaction.member, permission)) return true;

  const { EmbedBuilder } = require('discord.js');
  const embed = new EmbedBuilder()
    .setColor(0xE53E3E)
    .setTitle('🚫 Access Denied')
    .setDescription(`You don't have permission to use this command.\n\nRequired permission: **${permission.replace(/_/g, ' ')}**`)
    .setFooter({ text: 'Contact HR if you believe this is a mistake.' });

  await interaction.reply({ embeds: [embed], ephemeral: true });
  return false;
}

module.exports = { getMemberLevel, hasPermission, hasMinLevel, checkPerm, ROLE_HIERARCHY };
