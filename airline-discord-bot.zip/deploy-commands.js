const { REST, Routes } = require('discord.js');
require('dotenv').config();

const { createFlight, listFlights, flightInfo, updateFlight, cancelFlight } = require('./commands/flights/flightCommands');
const { bookFlight, myBookings, cancelBooking, viewBookings } = require('./commands/flights/bookingCommands');
const { hire, fire, promote, staffList, staffInfo } = require('./commands/staff/staffCommands');
const { setup, givePassengerRole, airlineInfo, stats, clearCancelled } = require('./commands/admin/adminCommands');

const commands = [
  createFlight, listFlights, flightInfo, updateFlight, cancelFlight,
  bookFlight, myBookings, cancelBooking, viewBookings,
  hire, fire, promote, staffList, staffInfo,
  setup, givePassengerRole, airlineInfo, stats, clearCancelled,
].map(c => c.data.toJSON());

const rest = new REST().setToken(process.env.TOKEN);

(async () => {
  try {
    console.log(`🔄 Registering ${commands.length} application commands...`);

    const data = await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: commands },
    );

    console.log(`✅ Successfully registered ${data.length} commands to guild ${process.env.GUILD_ID}`);
  } catch (error) {
    console.error('❌ Error registering commands:', error);
  }
})();
